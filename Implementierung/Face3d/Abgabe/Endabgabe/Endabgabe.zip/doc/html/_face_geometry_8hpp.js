var _face_geometry_8hpp =
[
    [ "FaceGeometry", "class_face3_d_1_1_face_geometry.html", "class_face3_d_1_1_face_geometry" ],
    [ "fileToPoint", "_face_geometry_8hpp.html#a8775123fe8a175f77279d65ac4dd1084", null ],
    [ "pointToFile", "_face_geometry_8hpp.html#ab2b03b98a8880918bf5ff4a81219cd25", null ]
];