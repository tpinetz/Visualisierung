var structstbi__io__callbacks =
[
    [ "eof", "structstbi__io__callbacks.html#a319639db2f76e715eed7a7a974136832", null ],
    [ "read", "structstbi__io__callbacks.html#a623e46b3a2a019611601409926283a88", null ],
    [ "skip", "structstbi__io__callbacks.html#a257aac5480a90a6c4b8fbe86c1b01068", null ]
];