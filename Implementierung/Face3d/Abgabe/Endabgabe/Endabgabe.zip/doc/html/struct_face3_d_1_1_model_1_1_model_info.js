var struct_face3_d_1_1_model_1_1_model_info =
[
    [ "allLeftEyeVertices", "struct_face3_d_1_1_model_1_1_model_info.html#a8ff9da28559de5ae3a242ce6e18fea75", null ],
    [ "allMouthVertices", "struct_face3_d_1_1_model_1_1_model_info.html#a31db594ca5e11d12cb5965c5a6e3ee2d", null ],
    [ "allNoseVertices", "struct_face3_d_1_1_model_1_1_model_info.html#a789b548861f05b8bd79f4a3f26b84bbb", null ],
    [ "allRightEyeVertices", "struct_face3_d_1_1_model_1_1_model_info.html#ab8c6d263cbdc8768344617e03d1e3c24", null ],
    [ "chin", "struct_face3_d_1_1_model_1_1_model_info.html#a1f6688ce6effce5f529d8b4f3019766e", null ],
    [ "leftEye", "struct_face3_d_1_1_model_1_1_model_info.html#a8c085a7458ad7cadd13c64a632faa837", null ],
    [ "modelDimension", "struct_face3_d_1_1_model_1_1_model_info.html#a4e2b64e11591be649d15eca8c6180376", null ],
    [ "modelPath", "struct_face3_d_1_1_model_1_1_model_info.html#a7f6cacf9ae39c86e2007f87dacff16e3", null ],
    [ "mouth", "struct_face3_d_1_1_model_1_1_model_info.html#ae0837733aacbb7d04ce34b2f240abf4f", null ],
    [ "nose", "struct_face3_d_1_1_model_1_1_model_info.html#afeddc5304d7cb7c77d3239efeef56747", null ],
    [ "rightEye", "struct_face3_d_1_1_model_1_1_model_info.html#acc12c6496e68aa15bcdf996f9bb3b58f", null ],
    [ "textureFront", "struct_face3_d_1_1_model_1_1_model_info.html#aa31a18f8553efbb08c1e06bbce4785d7", null ],
    [ "textureSide", "struct_face3_d_1_1_model_1_1_model_info.html#a0afbed21c950938c52f4a02da26cfb75", null ]
];