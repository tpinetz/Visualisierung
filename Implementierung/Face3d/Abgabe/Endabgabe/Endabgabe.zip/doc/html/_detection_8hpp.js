var _detection_8hpp =
[
    [ "Detection", "class_face3_d_1_1_detection.html", "class_face3_d_1_1_detection" ],
    [ "DetectFaceResult", "struct_face3_d_1_1_detection_1_1_detect_face_result.html", "struct_face3_d_1_1_detection_1_1_detect_face_result" ],
    [ "ContourInfo", "struct_face3_d_1_1_detection_1_1_contour_info.html", "struct_face3_d_1_1_detection_1_1_contour_info" ],
    [ "isConcave", "_detection_8hpp.html#a30822f87a9d45e34cd2e50fffdc8daac", null ],
    [ "onColorThresholdsTrackbar", "_detection_8hpp.html#a61c1e044078023b974eaae4e357f4749", null ],
    [ "onTextureAdjustmentTrackbar", "_detection_8hpp.html#abb3ec7550bca690a5e6249f98ef6b197", null ]
];