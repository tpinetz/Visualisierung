var class_face3_d_1_1_face_coordinates3d =
[
    [ "FacialPoints3d", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2", [
      [ "LeftEye", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2ae46fc9712285f861bf9db6cdca3b6f9d", null ],
      [ "RightEye", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a92625dad6ca65ec8758fe9cf1652997b", null ],
      [ "Mouth", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a39e45eff70c506fc33d410cc68ccb22b", null ],
      [ "Nose", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a36a8ea194a9ac6523814f63beb63ae8a", null ],
      [ "Chin", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2aeded0d266c30279d479ff6dd8a6c32cf", null ],
      [ "FaceDimensions", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a6c7721a39f6ff60dfa7bc73948d3bb05", null ],
      [ "TextureLeftEye", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a08b652a6b7f4c583c7258b277d12e861", null ],
      [ "TextureRightEye", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a65806d3ace05500db0e7e7150d23948f", null ],
      [ "TextureChin", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2ab3a011fe9e727dda63bb64a700ae52e8", null ],
      [ "InvalidPoint", "class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a7a89277f3a276a2c9c008860d4e73e99", null ]
    ] ],
    [ "fileToPoint", "class_face3_d_1_1_face_coordinates3d.html#adbc5a5615a2a469b98d995157445e4f7", null ],
    [ "fromFile", "class_face3_d_1_1_face_coordinates3d.html#a1c44e33ec6cd6c54c119d2a2ec4b49e7", null ],
    [ "getPoint", "class_face3_d_1_1_face_coordinates3d.html#aac912dcbb5db9d5ea1d6ca754afa5a39", null ],
    [ "m_Points", "class_face3_d_1_1_face_coordinates3d.html#aa4646a4766c4c5a8ce010ec05f49ffab", null ]
];