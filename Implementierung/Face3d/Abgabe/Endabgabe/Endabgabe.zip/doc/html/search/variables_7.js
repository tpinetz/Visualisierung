var searchData=
[
  ['normal',['normal',['../struct_face3_d_1_1_vertex.html#ad1020723e88d1adeaaaa74569614ca64',1,'Face3D::Vertex']]],
  ['nose',['nose',['../class_face3_d_1_1_face_geometry.html#a51b5cf29a6deac13aad7ab3ba3858eca',1,'Face3D::FaceGeometry::nose()'],['../struct_face3_d_1_1_model_1_1_model_info.html#afeddc5304d7cb7c77d3239efeef56747',1,'Face3D::Model::ModelInfo::nose()']]]
];
