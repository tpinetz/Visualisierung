var searchData=
[
  ['nose',['Nose',['../class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a36a8ea194a9ac6523814f63beb63ae8a',1,'Face3D::FaceCoordinates3d']]]
];
