var searchData=
[
  ['regiontypeinside',['RegionTypeInside',['../class_face3_d_1_1_detection.html#a8db79da2a4506aa0e799e4ff098d7d62a7714301dcaabe0757b2a1de73d08bf82',1,'Face3D::Detection']]],
  ['regiontypeoutside',['RegionTypeOutside',['../class_face3_d_1_1_detection.html#a8db79da2a4506aa0e799e4ff098d7d62acdeffba67fe972b99a5a38bcde0061f3',1,'Face3D::Detection']]],
  ['righteye',['RightEye',['../class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a92625dad6ca65ec8758fe9cf1652997b',1,'Face3D::FaceCoordinates3d']]]
];
