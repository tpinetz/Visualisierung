var searchData=
[
  ['chin',['chin',['../class_face3_d_1_1_face_geometry.html#a1c10c36a6624d30328d54b28f2829ac0',1,'Face3D::FaceGeometry::chin()'],['../struct_face3_d_1_1_model_1_1_model_info.html#a1f6688ce6effce5f529d8b4f3019766e',1,'Face3D::Model::ModelInfo::chin()']]],
  ['cogx',['cogX',['../struct_face3_d_1_1_detection_1_1_contour_info.html#ab3b12cdb015852630da5d8dce2f293ee',1,'Face3D::Detection::ContourInfo']]],
  ['cogy',['cogY',['../struct_face3_d_1_1_detection_1_1_contour_info.html#ad7c5269ab9a7fa7b968d6d4d6311ede0',1,'Face3D::Detection::ContourInfo']]],
  ['contour',['contour',['../struct_face3_d_1_1_detection_1_1_contour_info.html#a758e6ad092c81d6c8b9e25bc35f07e53',1,'Face3D::Detection::ContourInfo']]]
];
