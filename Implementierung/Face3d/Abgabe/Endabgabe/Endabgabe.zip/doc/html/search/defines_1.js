var searchData=
[
  ['gl_5fdebug',['GL_DEBUG',['../_g_l_header_8hpp.html#a26fb938ba96b8fd46d1f0f6552d0dde1',1,'GLHeader.hpp']]],
  ['glew_5fstatic',['GLEW_STATIC',['../_g_l_header_8hpp.html#abcde84ea0ef5f934384e4620f092c85a',1,'GLHeader.hpp']]]
];
