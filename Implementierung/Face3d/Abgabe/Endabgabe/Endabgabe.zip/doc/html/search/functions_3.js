var searchData=
[
  ['extractcontourinfo',['extractContourInfo',['../class_face3_d_1_1_detection.html#ae9ca9a340a1f81db0fa240045da86017',1,'Face3D::Detection']]]
];
