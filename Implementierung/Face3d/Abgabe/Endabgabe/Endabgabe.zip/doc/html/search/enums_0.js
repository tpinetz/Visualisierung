var searchData=
[
  ['detectedpoints',['DetectedPoints',['../class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11',1,'Face3D::FaceGeometry']]]
];
