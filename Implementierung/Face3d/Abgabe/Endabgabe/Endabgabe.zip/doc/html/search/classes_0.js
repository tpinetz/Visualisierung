var searchData=
[
  ['contourinfo',['ContourInfo',['../struct_face3_d_1_1_detection_1_1_contour_info.html',1,'Face3D::Detection']]]
];
