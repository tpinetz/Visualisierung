var searchData=
[
  ['lefteye',['leftEye',['../class_face3_d_1_1_face_geometry.html#a67446b08935c867d465743452d674f71',1,'Face3D::FaceGeometry::leftEye()'],['../struct_face3_d_1_1_model_1_1_model_info.html#a8c085a7458ad7cadd13c64a632faa837',1,'Face3D::Model::ModelInfo::leftEye()']]]
];
