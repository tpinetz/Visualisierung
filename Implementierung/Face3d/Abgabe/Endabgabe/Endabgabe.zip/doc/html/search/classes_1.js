var searchData=
[
  ['detectfaceresult',['DetectFaceResult',['../struct_face3_d_1_1_detection_1_1_detect_face_result.html',1,'Face3D::Detection']]],
  ['detection',['Detection',['../class_face3_d_1_1_detection.html',1,'Face3D']]]
];
