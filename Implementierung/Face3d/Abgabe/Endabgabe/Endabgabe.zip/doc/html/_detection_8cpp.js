var _detection_8cpp =
[
    [ "_USE_MATH_DEFINES", "_detection_8cpp.html#a525335710b53cb064ca56b936120431e", null ],
    [ "isConcave", "_detection_8cpp.html#a30822f87a9d45e34cd2e50fffdc8daac", null ],
    [ "onColorThresholdsTrackbar", "_detection_8cpp.html#a61c1e044078023b974eaae4e357f4749", null ],
    [ "onTextureAdjustmentTrackbarBottom", "_detection_8cpp.html#a9c8eef43bd9635c7b45779ee075115b2", null ],
    [ "onTextureAdjustmentTrackbarTop", "_detection_8cpp.html#a233335d6ebf7a5bf74368546dd6ed251", null ]
];