var annotated_dup =
[
    [ "Face3D", "namespace_face3_d.html", "namespace_face3_d" ],
    [ "stbi_io_callbacks", "structstbi__io__callbacks.html", "structstbi__io__callbacks" ]
];