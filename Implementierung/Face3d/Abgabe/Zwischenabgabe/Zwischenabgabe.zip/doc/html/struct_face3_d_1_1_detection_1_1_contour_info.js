var struct_face3_d_1_1_detection_1_1_contour_info =
[
    [ "ContourInfo", "struct_face3_d_1_1_detection_1_1_contour_info.html#a93e812ae1bdc43e561accee3040185ef", null ],
    [ "operator<", "struct_face3_d_1_1_detection_1_1_contour_info.html#a36d082505c98919d94ffb041016c436e", null ],
    [ "areaOfContour", "struct_face3_d_1_1_detection_1_1_contour_info.html#a2622475368ea0295120fde0d57daca5f", null ],
    [ "cogX", "struct_face3_d_1_1_detection_1_1_contour_info.html#ab3b12cdb015852630da5d8dce2f293ee", null ],
    [ "cogY", "struct_face3_d_1_1_detection_1_1_contour_info.html#ad7c5269ab9a7fa7b968d6d4d6311ede0", null ],
    [ "contour", "struct_face3_d_1_1_detection_1_1_contour_info.html#a758e6ad092c81d6c8b9e25bc35f07e53", null ]
];