var class_face3_d_1_1_detection =
[
    [ "ContourInfo", "struct_face3_d_1_1_detection_1_1_contour_info.html", "struct_face3_d_1_1_detection_1_1_contour_info" ],
    [ "DetectFaceResult", "struct_face3_d_1_1_detection_1_1_detect_face_result.html", "struct_face3_d_1_1_detection_1_1_detect_face_result" ],
    [ "RegionType", "class_face3_d_1_1_detection.html#a8db79da2a4506aa0e799e4ff098d7d62", [
      [ "RegionTypeInside", "class_face3_d_1_1_detection.html#a8db79da2a4506aa0e799e4ff098d7d62a7714301dcaabe0757b2a1de73d08bf82", null ],
      [ "RegionTypeOutside", "class_face3_d_1_1_detection.html#a8db79da2a4506aa0e799e4ff098d7d62acdeffba67fe972b99a5a38bcde0061f3", null ]
    ] ],
    [ "Detection", "class_face3_d_1_1_detection.html#ab51a4a8e01db10e473fa38db9d77fd18", null ],
    [ "createTextures", "class_face3_d_1_1_detection.html#a7a6c141eb4ecee4385a84b541275f1df", null ],
    [ "detectFace", "class_face3_d_1_1_detection.html#ac00b0ed49bbcc9efeccf307309b1723a", null ],
    [ "doFaceExtraction", "class_face3_d_1_1_detection.html#a424c3fba1ee4b7d24a84edebca9ecf14", null ],
    [ "doFacialComponentsExtraction", "class_face3_d_1_1_detection.html#a2345b11759e84ca94409cb65cef557f3", null ],
    [ "doFacialComponentsExtractionFront", "class_face3_d_1_1_detection.html#aeca140a4cb5eb2d035afabd66b90b42c", null ],
    [ "doFacialComponentsExtractionSide", "class_face3_d_1_1_detection.html#ae630778f107162e95580608fcb87aedc", null ],
    [ "doMatchCoordinates", "class_face3_d_1_1_detection.html#a0cf36050ade66d18074b6fa78ee7c7ca", null ],
    [ "doPreprocessing", "class_face3_d_1_1_detection.html#a0b4b0034dd25890ac492854d825c3ea1", null ],
    [ "extractContourInfo", "class_face3_d_1_1_detection.html#ae9ca9a340a1f81db0fa240045da86017", null ],
    [ "findRegions", "class_face3_d_1_1_detection.html#a2685b94451caa0572d6d209c936160b4", null ],
    [ "getBoundingBox", "class_face3_d_1_1_detection.html#ac4cc64a1037a3e09f8e7b8016528bafd", null ],
    [ "getCopyOfOriginal", "class_face3_d_1_1_detection.html#ad151547c47b89dc4673c51c43e22b6d3", null ],
    [ "frontImgNr", "class_face3_d_1_1_detection.html#a1c1137f1d9972fd213a04f93084a0d5c", null ],
    [ "imgSize", "class_face3_d_1_1_detection.html#a7d9ef90ae57f59f0e73edec0dffd9bd7", null ],
    [ "m_FaceExtracted", "class_face3_d_1_1_detection.html#a835e20dfe0fc3c9cee63168c4467dd82", null ],
    [ "m_FaceGeometry", "class_face3_d_1_1_detection.html#a4eed1e18b8465d43d75102bf10ce8575", null ],
    [ "m_FaceMask", "class_face3_d_1_1_detection.html#a4dff33b175f5b2aff949db62e4c95b88", null ],
    [ "m_Originals", "class_face3_d_1_1_detection.html#a237f409f79b8417f906732dc522322a8", null ],
    [ "m_Preprocessed", "class_face3_d_1_1_detection.html#a022bcdfdcfab58bcd2bb4f448d583b3c", null ],
    [ "m_Textures", "class_face3_d_1_1_detection.html#a5dbd240320bc7a4c1661b63e23bee777", null ],
    [ "sideImgNr", "class_face3_d_1_1_detection.html#a7a2e671e0ba9133f1fd8e877bc5a89f9", null ]
];