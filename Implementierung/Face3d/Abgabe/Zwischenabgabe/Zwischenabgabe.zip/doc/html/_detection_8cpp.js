var _detection_8cpp =
[
    [ "_USE_MATH_DEFINES", "_detection_8cpp.html#a525335710b53cb064ca56b936120431e", null ]
];