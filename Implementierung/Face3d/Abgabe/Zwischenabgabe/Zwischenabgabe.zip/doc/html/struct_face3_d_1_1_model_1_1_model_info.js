var struct_face3_d_1_1_model_1_1_model_info =
[
    [ "leftEye", "struct_face3_d_1_1_model_1_1_model_info.html#a8c085a7458ad7cadd13c64a632faa837", null ],
    [ "modelPath", "struct_face3_d_1_1_model_1_1_model_info.html#a7f6cacf9ae39c86e2007f87dacff16e3", null ],
    [ "mouth", "struct_face3_d_1_1_model_1_1_model_info.html#ae0837733aacbb7d04ce34b2f240abf4f", null ],
    [ "rightEye", "struct_face3_d_1_1_model_1_1_model_info.html#acc12c6496e68aa15bcdf996f9bb3b58f", null ],
    [ "textureFront", "struct_face3_d_1_1_model_1_1_model_info.html#aa31a18f8553efbb08c1e06bbce4785d7", null ],
    [ "textureSide", "struct_face3_d_1_1_model_1_1_model_info.html#a0afbed21c950938c52f4a02da26cfb75", null ]
];