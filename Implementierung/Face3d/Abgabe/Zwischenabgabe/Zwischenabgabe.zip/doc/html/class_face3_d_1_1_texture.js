var class_face3_d_1_1_texture =
[
    [ "TextureSetting", "class_face3_d_1_1_texture.html#aa2d0d0213ac74b112ce13cf5511a0573", [
      [ "TextureLinear", "class_face3_d_1_1_texture.html#aa2d0d0213ac74b112ce13cf5511a0573a14d9ede2b469d8bdeb6104a7e3e3297f", null ],
      [ "TextureNearest", "class_face3_d_1_1_texture.html#aa2d0d0213ac74b112ce13cf5511a0573a97cc8a0412885c34a8f6a0245fad6734", null ],
      [ "TextureMIPNearest", "class_face3_d_1_1_texture.html#aa2d0d0213ac74b112ce13cf5511a0573a3e3b46677c939a73b353a823c5606e27", null ],
      [ "TextureMIPLinear", "class_face3_d_1_1_texture.html#aa2d0d0213ac74b112ce13cf5511a0573a9d4b4ece6a682bd39df531f0ddc28988", null ]
    ] ],
    [ "Texture", "class_face3_d_1_1_texture.html#af22c3684f7cef6023862f61cab25bb98", null ],
    [ "changeTextureSettings", "class_face3_d_1_1_texture.html#aa7f450d79daebff981fb5a7dc3c9a85e", null ],
    [ "getSamplerID", "class_face3_d_1_1_texture.html#ac579a87306902c623255a446c26f14b9", null ],
    [ "getSetting", "class_face3_d_1_1_texture.html#a975cd5d43b1a8009df6498d81c539851", null ],
    [ "Instance", "class_face3_d_1_1_texture.html#a1e8b06b1ae91ab8256b36dad8d6ec389", null ],
    [ "Texture::loadFromImage", "class_face3_d_1_1_texture.html#a297188d7d9549841d4351d8d0017aadf", null ],
    [ "m_CurrSetting", "class_face3_d_1_1_texture.html#ab3ef103303845ee062b3c2d0618d6c32", null ],
    [ "m_TextureCache", "class_face3_d_1_1_texture.html#a12f88846d60462abc4898b0a9cc54bf9", null ],
    [ "samplerID", "class_face3_d_1_1_texture.html#a4d9b0c399e52a64c72f096ffb768e6e7", null ]
];