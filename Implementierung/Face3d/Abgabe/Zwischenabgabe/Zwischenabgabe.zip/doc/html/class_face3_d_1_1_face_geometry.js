var class_face3_d_1_1_face_geometry =
[
    [ "DetectedPoints", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11", [
      [ "FrontLeftEye", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11a3b8d42b7b6a50b21aa7b45f91d6ca101", null ],
      [ "FrontRightEye", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11a8f7e43bdc4f5063cbd2077f07839fefa", null ],
      [ "FrontMouth", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11ae026cb5d275298596d8271989547f308", null ],
      [ "SideEye", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11ae6070e4323042c54fd618a58ee59096d", null ],
      [ "SideNoseTip", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11aede62853a8d83e60bedafd0ad9fccaf6", null ],
      [ "InvalidPoint", "class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11aef08736c0cf92fe26e5d281571ac319d", null ]
    ] ],
    [ "DetectedRegions", "class_face3_d_1_1_face_geometry.html#a6db32685a7f429d507b8e31f7c42fe77", [
      [ "FrontFacialRegion", "class_face3_d_1_1_face_geometry.html#a6db32685a7f429d507b8e31f7c42fe77ab67d7eec01dde53411fead2352b3225f", null ],
      [ "SideFacialRegion", "class_face3_d_1_1_face_geometry.html#a6db32685a7f429d507b8e31f7c42fe77a2e8f6c6895172ac83574e641b90de35a", null ],
      [ "InvalidRegion", "class_face3_d_1_1_face_geometry.html#a6db32685a7f429d507b8e31f7c42fe77ac1c1cfae295c068738737d0bdbd3cb78", null ]
    ] ],
    [ "getDetectedPoint", "class_face3_d_1_1_face_geometry.html#a9ce57cf061663a02267d9fee423dbc73", null ],
    [ "getDetectedPointHomogeneous", "class_face3_d_1_1_face_geometry.html#a6aed421ae667cc1b67b4bf6a891ff634", null ],
    [ "getDetectedPointInt", "class_face3_d_1_1_face_geometry.html#a3c4e46361330951648193f24b8a5329d", null ],
    [ "getDetectedRegion", "class_face3_d_1_1_face_geometry.html#a85251824e8909cca4d35461744ccc40f", null ],
    [ "merge3d", "class_face3_d_1_1_face_geometry.html#a653c167dc85c8eb861fa8fba73ecfd72", null ],
    [ "pointToFile", "class_face3_d_1_1_face_geometry.html#adfb84290b1363a7f37c785640464bc42", null ],
    [ "setDetectedPoint", "class_face3_d_1_1_face_geometry.html#a0cbcfd1b63284e1d1fa1f91a87b8f06a", null ],
    [ "setDetectedPoint", "class_face3_d_1_1_face_geometry.html#a737543f3299fee8c845f2af2e25355e1", null ],
    [ "setDetectedRegion", "class_face3_d_1_1_face_geometry.html#a9728c2a48b99682f74910f8924cc3f91", null ],
    [ "toFile", "class_face3_d_1_1_face_geometry.html#a7ff82baf7bb2a3f2ddc883a34e9ca945", null ],
    [ "transform", "class_face3_d_1_1_face_geometry.html#a876baec2ea039287ec5d45784d9b0242", null ],
    [ "frontSkinRegion", "class_face3_d_1_1_face_geometry.html#aec3c5ac2a67745348df5aa68651bf616", null ],
    [ "leftEye", "class_face3_d_1_1_face_geometry.html#a67446b08935c867d465743452d674f71", null ],
    [ "m_DetectedPoints", "class_face3_d_1_1_face_geometry.html#a695d2f7b17ed80f56f4e6af44c796a9a", null ],
    [ "m_DetectedRegions", "class_face3_d_1_1_face_geometry.html#a41bdb9ec230523b1bc19bc8f7f2b48ea", null ],
    [ "mouth", "class_face3_d_1_1_face_geometry.html#a1c36fe81650a276b523d8dc17b30038e", null ],
    [ "nose", "class_face3_d_1_1_face_geometry.html#a51b5cf29a6deac13aad7ab3ba3858eca", null ],
    [ "rightEye", "class_face3_d_1_1_face_geometry.html#a2843e84aaa697a4cd418d1940378955b", null ],
    [ "sideSkinRegion", "class_face3_d_1_1_face_geometry.html#a50fd03eb7de07088b36d3e4dea286b94", null ]
];