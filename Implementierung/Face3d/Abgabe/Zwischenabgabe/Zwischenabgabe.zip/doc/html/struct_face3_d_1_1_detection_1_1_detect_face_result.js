var struct_face3_d_1_1_detection_1_1_detect_face_result =
[
    [ "faceGeometry", "struct_face3_d_1_1_detection_1_1_detect_face_result.html#acbc7132009d7bda34c42414c023a965e", null ],
    [ "textureFront", "struct_face3_d_1_1_detection_1_1_detect_face_result.html#a2377f5ef21e5b7a4f1194ef42963f4c6", null ],
    [ "textureSide", "struct_face3_d_1_1_detection_1_1_detect_face_result.html#a2a38d56093e878bb3bd363583d1667a3", null ]
];