var searchData=
[
  ['detectedpoints',['DetectedPoints',['../class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11',1,'Face3D::FaceGeometry']]],
  ['detectedregions',['DetectedRegions',['../class_face3_d_1_1_face_geometry.html#a6db32685a7f429d507b8e31f7c42fe77',1,'Face3D::FaceGeometry']]]
];
