var searchData=
[
  ['loadfromimage',['loadFromImage',['../class_face3_d_1_1_texture.html#a297188d7d9549841d4351d8d0017aadf',1,'Face3D::Texture']]],
  ['texture',['Texture',['../class_face3_d_1_1_texture.html#af22c3684f7cef6023862f61cab25bb98',1,'Face3D::Texture']]],
  ['tofile',['toFile',['../class_face3_d_1_1_face_geometry.html#a7ff82baf7bb2a3f2ddc883a34e9ca945',1,'Face3D::FaceGeometry']]],
  ['transform',['transform',['../class_face3_d_1_1_face_geometry.html#a876baec2ea039287ec5d45784d9b0242',1,'Face3D::FaceGeometry']]]
];
