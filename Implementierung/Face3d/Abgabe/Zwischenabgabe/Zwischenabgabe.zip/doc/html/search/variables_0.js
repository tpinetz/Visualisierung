var searchData=
[
  ['areaofcontour',['areaOfContour',['../struct_face3_d_1_1_detection_1_1_contour_info.html#a2622475368ea0295120fde0d57daca5f',1,'Face3D::Detection::ContourInfo']]]
];
