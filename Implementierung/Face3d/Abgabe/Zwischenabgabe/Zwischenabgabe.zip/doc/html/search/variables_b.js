var searchData=
[
  ['texturefront',['textureFront',['../struct_face3_d_1_1_detection_1_1_detect_face_result.html#a2377f5ef21e5b7a4f1194ef42963f4c6',1,'Face3D::Detection::DetectFaceResult::textureFront()'],['../struct_face3_d_1_1_model_1_1_model_info.html#aa31a18f8553efbb08c1e06bbce4785d7',1,'Face3D::Model::ModelInfo::textureFront()']]],
  ['textureside',['textureSide',['../struct_face3_d_1_1_detection_1_1_detect_face_result.html#a2a38d56093e878bb3bd363583d1667a3',1,'Face3D::Detection::DetectFaceResult::textureSide()'],['../struct_face3_d_1_1_model_1_1_model_info.html#a0afbed21c950938c52f4a02da26cfb75',1,'Face3D::Model::ModelInfo::textureSide()']]]
];
