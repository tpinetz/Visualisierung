var searchData=
[
  ['imgsize',['imgSize',['../class_face3_d_1_1_detection.html#a7d9ef90ae57f59f0e73edec0dffd9bd7',1,'Face3D::Detection']]]
];
