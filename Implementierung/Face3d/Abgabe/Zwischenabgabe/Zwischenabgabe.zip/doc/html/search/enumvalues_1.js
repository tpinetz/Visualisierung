var searchData=
[
  ['invalidpoint',['InvalidPoint',['../class_face3_d_1_1_face_coordinates3d.html#a8bedd28eb0ab2749aa98a888921ea2b2a7a89277f3a276a2c9c008860d4e73e99',1,'Face3D::FaceCoordinates3d::InvalidPoint()'],['../class_face3_d_1_1_face_geometry.html#aab597f00966010882927a4974649bf11aef08736c0cf92fe26e5d281571ac319d',1,'Face3D::FaceGeometry::InvalidPoint()']]],
  ['invalidregion',['InvalidRegion',['../class_face3_d_1_1_face_geometry.html#a6db32685a7f429d507b8e31f7c42fe77ac1c1cfae295c068738737d0bdbd3cb78',1,'Face3D::FaceGeometry']]]
];
