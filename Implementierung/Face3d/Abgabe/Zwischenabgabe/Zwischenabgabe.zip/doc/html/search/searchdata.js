var indexSectionsWithContent =
{
  0: "_acdefgilmnoprstv",
  1: "cdfmstv",
  2: "f",
  3: "cdfgmstv",
  4: "acdefgilmoprst",
  5: "acefilmnprst",
  6: "s",
  7: "dfrt",
  8: "filmnrst",
  9: "_gs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros"
};

