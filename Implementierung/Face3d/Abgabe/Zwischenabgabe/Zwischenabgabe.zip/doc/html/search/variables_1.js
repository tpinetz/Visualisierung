var searchData=
[
  ['cogx',['cogX',['../struct_face3_d_1_1_detection_1_1_contour_info.html#ab3b12cdb015852630da5d8dce2f293ee',1,'Face3D::Detection::ContourInfo']]],
  ['cogy',['cogY',['../struct_face3_d_1_1_detection_1_1_contour_info.html#ad7c5269ab9a7fa7b968d6d4d6311ede0',1,'Face3D::Detection::ContourInfo']]],
  ['contour',['contour',['../struct_face3_d_1_1_detection_1_1_contour_info.html#a758e6ad092c81d6c8b9e25bc35f07e53',1,'Face3D::Detection::ContourInfo']]]
];
