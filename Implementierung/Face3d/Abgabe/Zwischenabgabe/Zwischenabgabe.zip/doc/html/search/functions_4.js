var searchData=
[
  ['filetopoint',['fileToPoint',['../class_face3_d_1_1_face_coordinates3d.html#adbc5a5615a2a469b98d995157445e4f7',1,'Face3D::FaceCoordinates3d']]],
  ['findregions',['findRegions',['../class_face3_d_1_1_detection.html#a2685b94451caa0572d6d209c936160b4',1,'Face3D::Detection']]],
  ['fromfile',['fromFile',['../class_face3_d_1_1_face_coordinates3d.html#a1c44e33ec6cd6c54c119d2a2ec4b49e7',1,'Face3D::FaceCoordinates3d']]]
];
