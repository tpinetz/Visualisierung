var searchData=
[
  ['_5fuse_5fmath_5fdefines',['_USE_MATH_DEFINES',['../_detection_8cpp.html#a525335710b53cb064ca56b936120431e',1,'_USE_MATH_DEFINES():&#160;Detection.cpp'],['../_model_8cpp.html#a525335710b53cb064ca56b936120431e',1,'_USE_MATH_DEFINES():&#160;Model.cpp']]]
];
