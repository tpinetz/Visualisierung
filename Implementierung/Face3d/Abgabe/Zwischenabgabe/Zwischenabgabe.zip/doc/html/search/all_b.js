var searchData=
[
  ['operator_3c',['operator&lt;',['../struct_face3_d_1_1_detection_1_1_contour_info.html#a36d082505c98919d94ffb041016c436e',1,'Face3D::Detection::ContourInfo']]]
];
