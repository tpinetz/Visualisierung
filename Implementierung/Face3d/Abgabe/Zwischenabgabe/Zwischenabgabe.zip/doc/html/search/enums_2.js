var searchData=
[
  ['regiontype',['RegionType',['../class_face3_d_1_1_detection.html#a8db79da2a4506aa0e799e4ff098d7d62',1,'Face3D::Detection']]]
];
