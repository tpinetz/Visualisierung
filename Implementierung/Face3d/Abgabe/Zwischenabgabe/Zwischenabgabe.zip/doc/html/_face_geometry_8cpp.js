var _face_geometry_8cpp =
[
    [ "fileToPoint", "_face_geometry_8cpp.html#a8775123fe8a175f77279d65ac4dd1084", null ],
    [ "pointToFile", "_face_geometry_8cpp.html#ab2b03b98a8880918bf5ff4a81219cd25", null ]
];