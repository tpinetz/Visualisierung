var struct_face3_d_1_1_vertex =
[
    [ "normal", "struct_face3_d_1_1_vertex.html#ad1020723e88d1adeaaaa74569614ca64", null ],
    [ "position", "struct_face3_d_1_1_vertex.html#a79ac5e4dc9a0fd62c167ffdaac9516b1", null ]
];